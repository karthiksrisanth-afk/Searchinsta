const connectCard = document.querySelector("#connectCard");
const searchArea = document.querySelector("#searchArea");
const disconnect = document.querySelector("#disconnect");
const avatar = document.querySelector("#avatar");
const username = document.querySelector("#username");
const name = document.querySelector("#name");
const input = document.querySelector("#search");
const clear = document.querySelector("#clear");
const results = document.querySelector("#results");
const demo = document.querySelector("#demo");

let timer;

async function status() {
  const r = await fetch("/api/status");
  const data = await r.json();

  if (!data.connected) return;

  connectCard.classList.add("hidden");
  searchArea.classList.remove("hidden");
  disconnect.classList.remove("hidden");

  username.textContent = data.profile?.username
    ? "@" + data.profile.username
    : "Connected";
  name.textContent = data.profile?.name || "Instagram account";
  if (data.profile?.profile_picture_url) {
    avatar.src = data.profile.profile_picture_url;
  }
}

function escapeHtml(value = "") {
  return value.replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

function render(items) {
  if (!items.length) {
    results.innerHTML = `<div class="empty">No matching Instagram data found.</div>`;
    return;
  }

  results.innerHTML = items.map(item => `
    <article class="result card">
      <div class="result-top">
        <div>
          <h3>${escapeHtml(item.media_type || "Media")}</h3>
          <p>${escapeHtml(item.caption || "(No caption)")}</p>
        </div>
        ${item.permalink ? `<a href="${escapeHtml(item.permalink)}" target="_blank" rel="noopener">Open ↗</a>` : ""}
      </div>
      <div class="meta">${escapeHtml(item.timestamp || "")} · ID ${escapeHtml(item.id || "")}</div>
    </article>
  `).join("");
}

async function search(q) {
  if (!q.trim()) {
    results.innerHTML = "";
    return;
  }

  results.innerHTML = `<div class="empty">Searching…</div>`;
  const r = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
  const data = await r.json();

  if (!r.ok) {
    results.innerHTML = `<div class="empty">${escapeHtml(data.error || "Search failed.")}</div>`;
    return;
  }

  render(data.results || []);
}

input.addEventListener("input", () => {
  clearTimeout(timer);
  timer = setTimeout(() => search(input.value), 300);
});

clear.addEventListener("click", () => {
  input.value = "";
  results.innerHTML = "";
  input.focus();
});

disconnect.addEventListener("click", async () => {
  await fetch("/api/logout", { method: "POST" });
  location.reload();
});

showDemo();

const sample = [
  {
    id: "sample_1001",
    media_type: "IMAGE",
    caption: "Birthday celebration ✨ #sample",
    timestamp: "2026-10-03T18:30:00+05:30",
    permalink: "#"
  },
  {
    id: "sample_1002",
    media_type: "VIDEO",
    caption: "Weekend memories and good vibes",
    timestamp: "2026-09-28T15:10:00+05:30",
    permalink: "#"
  },
  {
    id: "sample_1003",
    media_type: "CAROUSEL_ALBUM",
    caption: "School project — mathematics",
    timestamp: "2026-09-24T20:05:00+05:30",
    permalink: "#"
  }
];

function showDemo() {
  connectCard.classList.add("hidden");
  searchArea.classList.remove("hidden");
  disconnect.classList.add("hidden");
  username.textContent = "@sample_account";
  name.textContent = "Demo account";
  avatar.src = "/logo.svg";
  input.value = "";
  results.innerHTML = `
    <div class="hint"><span class="sample-label">DEMO DATA</span><br>
    This is sample content. It is not retrieved from Instagram.</div>`;
  results.innerHTML += sample.map(item => `
    <article class="result card">
      <div class="result-top">
        <div>
          <h3>${escapeHtml(item.media_type)}</h3>
          <p>${escapeHtml(item.caption)}</p>
        </div>
        <a href="#" onclick="return false;">Sample ↗</a>
      </div>
      <div class="meta">${escapeHtml(item.timestamp)} · ID ${escapeHtml(item.id)}</div>
    </article>
  `).join("");
}

demo?.addEventListener("click", showDemo);
